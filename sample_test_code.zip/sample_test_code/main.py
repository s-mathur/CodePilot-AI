from fastapi import FastAPI
from routers.auth import router as auth_router
from routers.users import router as user_router

app = FastAPI()

app.include_router(auth_router)
app.include_router(user_router)


@app.get("/")
def home():
    return {"message": "Welcome"}