DEBUG = True

PROJECT_NAME = (
    "Sample FastAPI Project"
)