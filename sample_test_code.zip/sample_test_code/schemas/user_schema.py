class UserSchema:

    id: int
    name: str