from utils.jwt_manager import create_access_token


def login_user(username, password):

    if username == "admin":

        token = create_access_token(
            username
        )

        return {

            "status": "success",
            "token": token
        }

    return {

        "status": "failed"
    }