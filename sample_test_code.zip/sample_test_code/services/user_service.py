from database.models import User


def get_user_details(user_id):

    return {

        "id": user_id,
        "name": "Shubham"
    }