import jwt
import datetime


SECRET_KEY = "MY_SECRET"


def create_access_token(username):

    payload = {

        "username": username,

        "exp":
        datetime.datetime.utcnow()
    }

    token = jwt.encode(
        payload,
        SECRET_KEY,
        algorithm="HS256"
    )

    return token