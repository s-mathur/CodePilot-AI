from fastapi import APIRouter
from services.user_service import get_user_details

router = APIRouter()


@router.get("/user")
def get_user(user_id: int):
    return get_user_details(user_id)